import { Component, OnInit } from '@angular/core';
import { StudentService } from '../student.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-list-student',
  templateUrl: './list-student.component.html',
  styleUrls: ['./list-student.component.scss'],
})
export class ListStudentComponent implements OnInit {

  constructor(private studentService:StudentService,private router:Router) { }
  student=[];




  ngOnInit() {
    this.student=this.studentService.students;

  }


deleteStudent(s){
  this.studentService.deleteStudent(s);
}

deleteAllStudents(){
  this.studentService.deleteAllStudents();
}

onSelect(rollno){
 
 //  console.log("id "+JSON.stringify(rollno));
  this.router.navigate(['/edit-student/'+rollno]);
  //this.studentService.onSelect(rollno);

}


}