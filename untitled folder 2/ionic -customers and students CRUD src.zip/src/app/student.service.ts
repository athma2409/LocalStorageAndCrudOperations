import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class StudentService {


  constructor(private router: Router) {

    var studentList = [
      {
        rollno: 1, firstName: "Athma", lastName: "Ram", dob: "01-07-1994", class: "FirstClass",
        subject: "Maths", teacher: "Vivek", address: "Bangalore"
      },

      {
        rollno: 2, firstName: "Ram", lastName: "Yajamanam", dob: "02-07-1994", class: "SecondClass",
        subject: "Programing", teacher: "Vijay", address: "Bangalore"
      }

    ];

    if (localStorage.getItem('students') == null || JSON.parse(localStorage.getItem('students')).length == 0) {

      this.students = studentList;
      this.setLocalStorageStudent(this.students);
    } else {
      this.getLocalStorageStudent();
    }

  }

  getLocalStorageStudent() {
    this.students = JSON.parse(localStorage.getItem('students'));

  }
  setLocalStorageStudent(list) {
    localStorage.setItem('students', JSON.stringify(list));
  }

  students = [
    {
      rollno: 1, firstName: "Athma", lastName: "Ram", dob: "01-07-1994", class: "FirstClass",
      subject: "Maths", teacher: "Vivek", address: "Bangalore"
    },

    {
      rollno: 2, firstName: "Athma", lastName: "Ram", dob: "01-07-1994", class: "SecondClass",
      subject: "Maths", teacher: "Vivek", address: "Bangalore"
    }
  ]

  getStudent() {
    if(localStorage.getItem('students')!=null)
          {
          this.students=JSON.parse(localStorage.getItem('students'));
          }
    return this.students;
  }

  deleteAllStudents() {
    this.students.length = 0;
    this.setLocalStorageStudent(this.students);

  }



  deleteStudent(s) {
    for (var i = 0; i < this.students.length; i++) {
      if (s.rollno == this.students[i].rollno) {
        this.students.splice(i, s.rollno);
      }
    }
    this.setLocalStorageStudent(this.students);

  }
  addStudent(student) {

    student.rollno = Math.round(Math.random() * 100000);
    this.students.push(student);
    // localStorage.setItem('persons',JSON.stringify(this.customers));
    this.setLocalStorageStudent(this.students);


  }

  getStudentById(rollno) {
    for (var i = 0; i < this.students.length; i++) {
      if (rollno == this.students[i].rollno) {
        return this.students[i];
      }
    }
    // localStorage.setItem('persons',JSON.stringify(this.customers));
    this.setLocalStorageStudent(this.students);


  }
  updateStudent(student) {
    for (var i = 0; i < this.students.length; i++) {
      if (this.students[i].rollno == student.rollno) {
        this.students[i] = student;
      }
    }
    // localStorage.setItem('customers',JSON.stringify(this.customers));
    this.setLocalStorageStudent(this.students);

  }




}





